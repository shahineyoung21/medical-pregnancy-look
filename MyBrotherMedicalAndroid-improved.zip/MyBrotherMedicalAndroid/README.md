# My Brother Medical — Android

Android client for the `superG_Agent` super-agent backend.

## Product idea
The Android app is the user-facing layer. The super-agent performs research, source verification, orchestration, and response generation.

Core modules planned:
- Medical Q&A with source citations
- Medication reminders
- Nutrition cards and visual explanations
- Safety / urgent-symptom guidance
- Source audit trail
- Arabic-first UI

## Backend contract
The current client expects:
`POST /v1/medical/ask`

Request:
```json
{"message":"...","locale":"ar"}
```

Response:
```json
{
  "answer":"...",
  "sources":[{"title":"...","url":"...","publisher":"...","publishedAt":"..."}],
  "safetyNote":"..."
}
```

### Setting the backend URL
Pass the URL at build time (never commit secrets):

```bash
./gradlew assembleDebug -PSUPER_AGENT_URL=https://your-super-agent.example
```

Or set it in `gradle.properties` locally (do **not** push this file if it contains real URLs/keys):

```
SUPER_AGENT_URL=https://your-super-agent.example
```

## Build locally
```bash
chmod +x gradlew
./gradlew assembleDebug
```
APK output: `app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions
Push to `main` or run the **Build Android APK** workflow manually.  
The debug APK is uploaded as a workflow artifact.

> If the project lives inside a subfolder (e.g. `MyBrotherMedicalAndroid/`), the workflow already uses `working-directory` for that path. Adjust it if you place the project at the repo root.

## Permissions used
- `INTERNET` + `ACCESS_NETWORK_STATE` — call the medical agent API
- `POST_NOTIFICATIONS` + `SCHEDULE_EXACT_ALARM` — medication reminders (planned)
- `RECEIVE_BOOT_COMPLETED` — restore reminders after reboot (planned)

## Safety
- This app does **not** replace a doctor.
- Never changes prescribed doses.
- Shows sources with every answer when available.
- Urgent symptoms must be evaluated by a professional.
