package com.mybrother.medical

import retrofit2.http.Body
import retrofit2.http.POST

interface AgentApi {
    @POST("/v1/medical/ask")
    suspend fun ask(@Body request: AskRequest): AskResponse
}

data class AskRequest(val message: String, val locale: String = "ar")

data class AskResponse(
    val answer: String,
    val sources: List<SourceItem> = emptyList(),
    val safetyNote: String? = null
)

data class SourceItem(
    val title: String,
    val url: String,
    val publisher: String,
    val publishedAt: String? = null
)
